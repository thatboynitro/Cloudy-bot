/**
 * Fetches a random gif URL from GIPHY for the given search term.
 * Returns null if the API key is missing or the request fails,
 * so commands can gracefully fall back to text-only.
 */
async function getRandomGif(query) {
  const apiKey = process.env.GIPHY_API_KEY;
  if (!apiKey) {
    console.error('[gif] GIPHY_API_KEY is not set — add it in Secrets and restart the bot.');
    return null;
  }

  try {
    const url = `https://api.giphy.com/v1/gifs/search?api_key=${apiKey}&q=${encodeURIComponent(query)}&limit=25&rating=pg-13`;
    const res = await fetch(url);
    if (!res.ok) {
      console.error(`[gif] GIPHY request failed: ${res.status} ${res.statusText}`);
      return null;
    }

    const data = await res.json();
    if (!data.data || data.data.length === 0) return null;

    const pick = data.data[Math.floor(Math.random() * data.data.length)];
    return pick.images.original.url;
  } catch (err) {
    console.error('[gif] Error fetching gif:', err.message);
    return null;
  }
}

module.exports = { getRandomGif };
