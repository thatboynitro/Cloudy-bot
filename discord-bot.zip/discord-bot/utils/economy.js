const fs = require('fs');
const path = require('path');

const DATA_FILE = path.join(__dirname, '..', 'data', 'economy.json');
const STARTING_BALANCE = 100;

function ensureFile() {
  const dir = path.dirname(DATA_FILE);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(DATA_FILE, JSON.stringify({ balances: {}, cooldowns: {} }, null, 2));
  }
}

function readData() {
  ensureFile();
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch {
    return { balances: {}, cooldowns: {} };
  }
}

function writeData(data) {
  ensureFile();
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

function getBalance(userId) {
  const data = readData();
  if (!(userId in data.balances)) {
    data.balances[userId] = STARTING_BALANCE;
    writeData(data);
  }
  return data.balances[userId];
}

function setBalance(userId, amount) {
  const data = readData();
  data.balances[userId] = Math.max(0, Math.round(amount));
  writeData(data);
  return data.balances[userId];
}

function addBalance(userId, amount) {
  const current = getBalance(userId);
  return setBalance(userId, current + amount);
}

function checkCooldown(userId, action, cooldownMs) {
  const data = readData();
  const key = `${action}:${userId}`;
  const last = data.cooldowns[key];
  const now = Date.now();

  if (last && now - last < cooldownMs) {
    return cooldownMs - (now - last); // ms remaining
  }

  data.cooldowns[key] = now;
  writeData(data);
  return 0;
}

function getAllBalances() {
  const data = readData();
  return data.balances;
}

module.exports = { getBalance, setBalance, addBalance, checkCooldown, getAllBalances };
