const { EmbedBuilder } = require('discord.js');

/**
 * Sends a moderation action embed to the configured log channel.
 * Silently does nothing if LOG_CHANNEL_ID isn't set or the channel can't be found.
 */
async function sendModLog(client, { action, color, target, moderator, reason, extraFields = [] }) {
  const channelId = process.env.LOG_CHANNEL_ID;
  if (!channelId) return;

  const channel = await client.channels.fetch(channelId).catch(() => null);
  if (!channel) return;

  const embed = new EmbedBuilder()
    .setColor(color)
    .setTitle(action)
    .addFields(
      { name: 'User', value: `${target.tag} (${target.id})`, inline: true },
      { name: 'Moderator', value: `${moderator.tag}`, inline: true },
      ...extraFields,
      { name: 'Reason', value: reason || 'No reason provided' },
    )
    .setThumbnail(target.displayAvatarURL())
    .setTimestamp();

  await channel.send({ embeds: [embed] }).catch(() => {});
}

module.exports = { sendModLog };
