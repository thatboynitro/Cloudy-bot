const STAFF_ROLE_NAMES = ['staff', 'moderator', 'mod', 'admin', 'administrator'];

/**
 * Returns true if the user has the given Discord permission,
 * OR has a role commonly used for staff (Staff/Mod/Moderator/Admin)
 * as a safety net in case permission overrides get misconfigured.
 */
function isStaff(interaction, permissionFlag) {
  if (interaction.memberPermissions?.has(permissionFlag)) return true;

  const roles = interaction.member?.roles?.cache;
  if (!roles) return false;

  return roles.some((role) => STAFF_ROLE_NAMES.includes(role.name.toLowerCase()));
}

module.exports = { isStaff };
