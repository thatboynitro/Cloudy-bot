const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getBalance, addBalance, checkCooldown } = require('../../utils/economy');

const COOLDOWN_MS = 30 * 60 * 1000; // 30 minutes
const SUCCESS_RATE = 0.4; // 40% chance to succeed

function formatTime(ms) {
  const mins = Math.ceil(ms / 60000);
  if (mins < 60) return `${mins} minute(s)`;
  return `${Math.ceil(mins / 60)} hour(s)`;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('steal')
    .setDescription('Attempt to steal coins from another member (risky!)')
    .addUserOption((opt) => opt.setName('user').setDescription('Who to steal from').setRequired(true)),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const thief = interaction.user;

    if (target.id === thief.id) {
      return interaction.reply({ content: 'You can\'t steal from yourself!', ephemeral: true });
    }
    if (target.bot) {
      return interaction.reply({ content: 'You can\'t steal from a bot.', ephemeral: true });
    }

    const remaining = checkCooldown(thief.id, 'steal', COOLDOWN_MS);
    if (remaining > 0) {
      return interaction.reply({
        content: `⏱️ You're laying low. Try stealing again in **${formatTime(remaining)}**.`,
        ephemeral: true,
      });
    }

    const targetBalance = getBalance(target.id);
    if (targetBalance < 20) {
      return interaction.reply({ content: `${target.username} doesn't have enough coins worth stealing.`, ephemeral: true });
    }

    const success = Math.random() < SUCCESS_RATE;

    if (success) {
      const amount = Math.floor(targetBalance * (Math.random() * 0.2 + 0.1)); // steal 10-30% of their balance
      addBalance(target.id, -amount);
      addBalance(thief.id, amount);

      const embed = new EmbedBuilder()
        .setColor(0x2ed573)
        .setDescription(`🕵️ You successfully stole **${amount}** coins from **${target.username}**!`);
      await interaction.reply({ embeds: [embed] });
    } else {
      const fine = Math.floor(Math.random() * 40) + 10; // 10-49
      addBalance(thief.id, -fine);

      const embed = new EmbedBuilder()
        .setColor(0xff4757)
        .setDescription(`🚔 You got caught trying to steal from **${target.username}** and paid a **${fine}** coin fine!`);
      await interaction.reply({ embeds: [embed] });
    }
  },
};
