const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getBalance, addBalance } = require('../../utils/economy');

const WIN_RATE = 0.47; // slightly under 50/50, like a real casino

module.exports = {
  data: new SlashCommandBuilder()
    .setName('gamble')
    .setDescription('Bet coins for a chance to double them (no cooldown, but risky!)')
    .addIntegerOption((opt) =>
      opt.setName('amount').setDescription('How many coins to bet').setRequired(true).setMinValue(1),
    ),
  async execute(interaction) {
    const amount = interaction.options.getInteger('amount');
    const balance = getBalance(interaction.user.id);

    if (amount > balance) {
      return interaction.reply({ content: `You only have **${balance}** coins.`, ephemeral: true });
    }

    const won = Math.random() < WIN_RATE;
    const newBalance = addBalance(interaction.user.id, won ? amount : -amount);

    const embed = new EmbedBuilder()
      .setColor(won ? 0x2ed573 : 0xff4757)
      .setDescription(
        won
          ? `🎰 You won! **+${amount}** coins.\nNew balance: **${newBalance}** coins.`
          : `🎰 You lost. **-${amount}** coins.\nNew balance: **${newBalance}** coins.`,
      );

    await interaction.reply({ embeds: [embed] });
  },
};
