const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getBalance } = require('../../utils/economy');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('balance')
    .setDescription('Check your (or someone else\'s) coin balance')
    .addUserOption((opt) => opt.setName('user').setDescription('Whose balance to check')),
  async execute(interaction) {
    const target = interaction.options.getUser('user') || interaction.user;
    const balance = getBalance(target.id);

    const embed = new EmbedBuilder()
      .setColor(0xf1c40f)
      .setDescription(`💰 **${target.username}** has **${balance}** coins.`);

    await interaction.reply({ embeds: [embed] });
  },
};
