const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { addBalance, checkCooldown } = require('../../utils/economy');

const COOLDOWN_MS = 20 * 60 * 1000; // 20 minutes
const SUCCESS_RATE = 0.55;

const CRIMES = [
  'hacked a vending machine', 'ran a fake raffle', 'pickpocketed a stranger',
  'jaywalked with confidence', 'sold "rare" NFTs', 'snuck into a movie theater',
];

function formatTime(ms) {
  const mins = Math.ceil(ms / 60000);
  return `${mins} minute(s)`;
}

module.exports = {
  data: new SlashCommandBuilder().setName('crime').setDescription('Commit a (fake) crime for a shot at coins — risky! (every 20 min)'),
  async execute(interaction) {
    const remaining = checkCooldown(interaction.user.id, 'crime', COOLDOWN_MS);
    if (remaining > 0) {
      return interaction.reply({
        content: `🚨 Lay low a bit longer. Try again in **${formatTime(remaining)}**.`,
        ephemeral: true,
      });
    }

    const crime = CRIMES[Math.floor(Math.random() * CRIMES.length)];
    const success = Math.random() < SUCCESS_RATE;

    if (success) {
      const earnings = Math.floor(Math.random() * 100) + 30; // 30-129
      const newBalance = addBalance(interaction.user.id, earnings);
      const embed = new EmbedBuilder()
        .setColor(0x2ed573)
        .setDescription(`😎 You ${crime} and got away with **${earnings}** coins!\nNew balance: **${newBalance}** coins.`);
      await interaction.reply({ embeds: [embed] });
    } else {
      const fine = Math.floor(Math.random() * 60) + 20; // 20-79
      const newBalance = addBalance(interaction.user.id, -fine);
      const embed = new EmbedBuilder()
        .setColor(0xff4757)
        .setDescription(`🚔 You ${crime} and got caught! Paid a **${fine}** coin fine.\nNew balance: **${newBalance}** coins.`);
      await interaction.reply({ embeds: [embed] });
    }
  },
};
