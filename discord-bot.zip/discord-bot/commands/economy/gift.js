const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getBalance, addBalance } = require('../../utils/economy');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('gift')
    .setDescription('Send some of your coins to another member')
    .addUserOption((opt) => opt.setName('user').setDescription('Who to gift coins to').setRequired(true))
    .addIntegerOption((opt) =>
      opt.setName('amount').setDescription('How many coins to gift').setRequired(true).setMinValue(1),
    ),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const amount = interaction.options.getInteger('amount');
    const sender = interaction.user;

    if (target.id === sender.id) {
      return interaction.reply({ content: 'You can\'t gift coins to yourself!', ephemeral: true });
    }
    if (target.bot) {
      return interaction.reply({ content: 'You can\'t gift coins to a bot.', ephemeral: true });
    }

    const senderBalance = getBalance(sender.id);
    if (senderBalance < amount) {
      return interaction.reply({ content: `You only have **${senderBalance}** coins.`, ephemeral: true });
    }

    addBalance(sender.id, -amount);
    addBalance(target.id, amount);

    const embed = new EmbedBuilder()
      .setColor(0x1e90ff)
      .setDescription(`🎁 **${sender.username}** gifted **${amount}** coins to **${target.username}**!`);

    await interaction.reply({ embeds: [embed] });
  },
};
