const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getAllBalances } = require('../../utils/economy');

module.exports = {
  data: new SlashCommandBuilder().setName('leaderboard').setDescription('See the top 10 richest members'),
  async execute(interaction) {
    await interaction.deferReply();

    const balances = getAllBalances();
    const entries = Object.entries(balances).map(([userId, amount]) => ({ userId, amount }));
    entries.sort((a, b) => b.amount - a.amount);
    const top = entries.slice(0, 10);

    if (top.length === 0) {
      return interaction.editReply('No one has a balance yet — try `/work` or `/daily` first!');
    }

    const lines = await Promise.all(
      top.map(async (entry, i) => {
        const user = await interaction.client.users.fetch(entry.userId).catch(() => null);
        const name = user ? user.username : `Unknown User (${entry.userId})`;
        const medal = ['🥇', '🥈', '🥉'][i] || `${i + 1}.`;
        return `${medal} **${name}** — ${entry.amount} coins`;
      }),
    );

    const embed = new EmbedBuilder()
      .setColor(0xf1c40f)
      .setTitle('🏆 Coin Leaderboard')
      .setDescription(lines.join('\n'));

    await interaction.editReply({ embeds: [embed] });
  },
};
