const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { addBalance, checkCooldown } = require('../../utils/economy');

const COOLDOWN_MS = 24 * 60 * 60 * 1000; // 24 hours
const REWARD = 200;

function formatTime(ms) {
  const hours = Math.ceil(ms / 3600000);
  return `${hours} hour(s)`;
}

module.exports = {
  data: new SlashCommandBuilder().setName('daily').setDescription('Claim your daily coin reward'),
  async execute(interaction) {
    const remaining = checkCooldown(interaction.user.id, 'daily', COOLDOWN_MS);
    if (remaining > 0) {
      return interaction.reply({
        content: `⏱️ You already claimed today. Come back in **${formatTime(remaining)}**.`,
        ephemeral: true,
      });
    }

    const newBalance = addBalance(interaction.user.id, REWARD);
    const embed = new EmbedBuilder()
      .setColor(0xf1c40f)
      .setDescription(`🎉 You claimed your daily reward of **${REWARD}** coins!\nNew balance: **${newBalance}** coins.`);

    await interaction.reply({ embeds: [embed] });
  },
};
