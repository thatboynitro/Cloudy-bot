const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { addBalance, checkCooldown } = require('../../utils/economy');

const COOLDOWN_MS = 5 * 60 * 1000; // 5 minutes

// Chance is out of 100 total. Rarer fish are worth more.
const FISH = [
  { name: 'Old Boot', emoji: '👢', chance: 15, value: 5 },
  { name: 'Minnow', emoji: '🐟', chance: 25, value: 15 },
  { name: 'Bluegill', emoji: '🐠', chance: 20, value: 25 },
  { name: 'Catfish', emoji: '🐡', chance: 15, value: 45 },
  { name: 'Silver Bass', emoji: '🐟', chance: 12, value: 70 },
  { name: 'Golden Trout', emoji: '✨🐟', chance: 7, value: 120 },
  { name: 'Rainbow Koi', emoji: '🌈🐠', chance: 4, value: 200 },
  { name: 'Kraken Hatchling', emoji: '🐙', chance: 1.5, value: 400 },
  { name: 'Legendary Sea Dragon', emoji: '🐉', chance: 0.5, value: 1000 },
];

function formatTime(ms) {
  const mins = Math.ceil(ms / 60000);
  return `${mins} minute(s)`;
}

function rollFish() {
  const roll = Math.random() * 100;
  let cumulative = 0;
  for (const fish of FISH) {
    cumulative += fish.chance;
    if (roll <= cumulative) return fish;
  }
  return FISH[0];
}

module.exports = {
  data: new SlashCommandBuilder().setName('fish').setDescription('Cast a line and try to catch something! (every 5 min)'),
  async execute(interaction) {
    const remaining = checkCooldown(interaction.user.id, 'fish', COOLDOWN_MS);
    if (remaining > 0) {
      return interaction.reply({
        content: `🎣 Your line needs re-baiting. Try again in **${formatTime(remaining)}**.`,
        ephemeral: true,
      });
    }

    const catchResult = rollFish();
    const newBalance = addBalance(interaction.user.id, catchResult.value);

    const embed = new EmbedBuilder()
      .setColor(0x1e90ff)
      .setTitle('🎣 Fishing')
      .setDescription(
        `You cast your line... and caught a **${catchResult.name}** ${catchResult.emoji}!\n\n` +
        `Worth **${catchResult.value}** coins.\nNew balance: **${newBalance}** coins.`,
      )
      .setFooter({ text: `Catch chance: ${catchResult.chance}%` });

    await interaction.reply({ embeds: [embed] });
  },
};
