const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { addBalance, checkCooldown } = require('../../utils/economy');

const COOLDOWN_MS = 60 * 60 * 1000; // 1 hour

const JOBS = [
  'delivered pizzas', 'walked some dogs', 'fixed a computer', 'wrote a song',
  'sold lemonade', 'streamed on Twitch', 'mowed a lawn', 'coded a website',
];

function formatTime(ms) {
  const mins = Math.ceil(ms / 60000);
  if (mins < 60) return `${mins} minute(s)`;
  return `${Math.ceil(mins / 60)} hour(s)`;
}

module.exports = {
  data: new SlashCommandBuilder().setName('work').setDescription('Work a job to earn coins (once per hour)'),
  async execute(interaction) {
    const remaining = checkCooldown(interaction.user.id, 'work', COOLDOWN_MS);
    if (remaining > 0) {
      return interaction.reply({
        content: `⏱️ You're tired! Try working again in **${formatTime(remaining)}**.`,
        ephemeral: true,
      });
    }

    const job = JOBS[Math.floor(Math.random() * JOBS.length)];
    const earnings = Math.floor(Math.random() * 80) + 20; // 20-99
    const newBalance = addBalance(interaction.user.id, earnings);

    const embed = new EmbedBuilder()
      .setColor(0x2ed573)
      .setDescription(`💼 You ${job} and earned **${earnings}** coins!\nNew balance: **${newBalance}** coins.`);

    await interaction.reply({ embeds: [embed] });
  },
};
