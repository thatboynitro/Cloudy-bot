const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { sendModLog } = require('../../utils/modlog');
const { isStaff } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Send a member a warning (DM + logged in channel)')
    .addUserOption((opt) => opt.setName('user').setDescription('Who to warn').setRequired(true))
    .addStringOption((opt) => opt.setName('reason').setDescription('Reason for the warning').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async execute(interaction) {
    if (!isStaff(interaction, PermissionFlagsBits.ModerateMembers)) {
      return interaction.reply({ content: 'You don\'t have permission to warn members.', ephemeral: true });
    }

    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason');

    const dmEmbed = new EmbedBuilder()
      .setColor(0xffd32a)
      .setTitle(`⚠️ You were warned in ${interaction.guild.name}`)
      .setThumbnail(interaction.guild.iconURL())
      .addFields({ name: 'Reason', value: reason })
      .setFooter({ text: 'Repeated warnings may lead to a mute, kick, or ban.' })
      .setTimestamp();

    await target.send({ embeds: [dmEmbed] }).catch(() => {
      // User may have DMs closed — that's fine, we still log it below.
    });

    const embed = new EmbedBuilder()
      .setColor(0xffd32a)
      .setTitle('⚠️ Member Warned')
      .addFields(
        { name: 'User', value: `${target.tag}`, inline: true },
        { name: 'Moderator', value: `${interaction.user.tag}`, inline: true },
        { name: 'Reason', value: reason },
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });

    await sendModLog(interaction.client, {
      action: '⚠️ Member Warned',
      color: 0xffd32a,
      target,
      moderator: interaction.user,
      reason,
    });
  },
};
