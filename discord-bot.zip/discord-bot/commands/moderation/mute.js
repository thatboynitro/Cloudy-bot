const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { sendModLog } = require('../../utils/modlog');
const { isStaff } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mute')
    .setDescription('Timeout (mute) a member for a number of minutes')
    .addUserOption((opt) => opt.setName('user').setDescription('Who to mute').setRequired(true))
    .addIntegerOption((opt) =>
      opt.setName('minutes').setDescription('How many minutes to mute for (max 40320 = 28 days)').setRequired(true),
    )
    .addStringOption((opt) => opt.setName('reason').setDescription('Reason for the mute'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async execute(interaction) {
    if (!isStaff(interaction, PermissionFlagsBits.ModerateMembers)) {
      return interaction.reply({ content: 'You don\'t have permission to mute members.', ephemeral: true });
    }

    const target = interaction.options.getUser('user');
    const minutes = interaction.options.getInteger('minutes');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (!member) {
      return interaction.reply({ content: 'That user isn\'t in this server.', ephemeral: true });
    }
    if (minutes < 1 || minutes > 40320) {
      return interaction.reply({ content: 'Minutes must be between 1 and 40320 (28 days).', ephemeral: true });
    }
    if (!member.moderatable) {
      return interaction.reply({ content: 'I can\'t mute that user — check role hierarchy and my permissions.', ephemeral: true });
    }

    await member.timeout(minutes * 60 * 1000, reason);

    const embed = new EmbedBuilder()
      .setColor(0x8395a7)
      .setTitle('🔇 Member Muted')
      .addFields(
        { name: 'User', value: `${target.tag}`, inline: true },
        { name: 'Duration', value: `${minutes} minute(s)`, inline: true },
        { name: 'Moderator', value: `${interaction.user.tag}`, inline: true },
        { name: 'Reason', value: reason },
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });

    await sendModLog(interaction.client, {
      action: '🔇 Member Muted',
      color: 0x8395a7,
      target,
      moderator: interaction.user,
      reason,
      extraFields: [{ name: 'Duration', value: `${minutes} minute(s)`, inline: true }],
    });
  },
};
