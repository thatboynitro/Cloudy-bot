const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { sendModLog } = require('../../utils/modlog');
const { isStaff } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban a member from the server')
    .addUserOption((opt) => opt.setName('user').setDescription('Who to ban').setRequired(true))
    .addStringOption((opt) => opt.setName('reason').setDescription('Reason for the ban'))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  async execute(interaction) {
    if (!isStaff(interaction, PermissionFlagsBits.BanMembers)) {
      return interaction.reply({ content: 'You don\'t have permission to ban members.', ephemeral: true });
    }

    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (!member) {
      return interaction.reply({ content: 'That user isn\'t in this server.', ephemeral: true });
    }
    if (!member.bannable) {
      return interaction.reply({ content: 'I can\'t ban that user — check role hierarchy and my permissions.', ephemeral: true });
    }

    const dmEmbed = new EmbedBuilder()
      .setColor(0xff0000)
      .setTitle(`🔨 You were banned from ${interaction.guild.name}`)
      .setThumbnail(interaction.guild.iconURL())
      .addFields({ name: 'Reason', value: reason })
      .setFooter({ text: 'If you believe this was a mistake, contact a server admin.' })
      .setTimestamp();

    await target.send({ embeds: [dmEmbed] }).catch(() => {
      // User may have DMs closed — that's fine, we still ban and log below.
    });

    await member.ban({ reason });

    const embed = new EmbedBuilder()
      .setColor(0xff0000)
      .setTitle('🔨 Member Banned')
      .addFields(
        { name: 'User', value: `${target.tag}`, inline: true },
        { name: 'Moderator', value: `${interaction.user.tag}`, inline: true },
        { name: 'Reason', value: reason },
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });

    await sendModLog(interaction.client, {
      action: '🔨 Member Banned',
      color: 0xff0000,
      target,
      moderator: interaction.user,
      reason,
    });
  },
};
