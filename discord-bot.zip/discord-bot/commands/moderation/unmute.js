const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { sendModLog } = require('../../utils/modlog');
const { isStaff } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unmute')
    .setDescription('Remove a timeout (mute) from a member')
    .addUserOption((opt) => opt.setName('user').setDescription('Who to unmute').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async execute(interaction) {
    if (!isStaff(interaction, PermissionFlagsBits.ModerateMembers)) {
      return interaction.reply({ content: 'You don\'t have permission to unmute members.', ephemeral: true });
    }

    const target = interaction.options.getUser('user');
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (!member) {
      return interaction.reply({ content: 'That user isn\'t in this server.', ephemeral: true });
    }

    await member.timeout(null);

    const embed = new EmbedBuilder()
      .setColor(0x2ed573)
      .setTitle('🔊 Member Unmuted')
      .addFields(
        { name: 'User', value: `${target.tag}`, inline: true },
        { name: 'Moderator', value: `${interaction.user.tag}`, inline: true },
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });

    await sendModLog(interaction.client, {
      action: '🔊 Member Unmuted',
      color: 0x2ed573,
      target,
      moderator: interaction.user,
      reason: 'N/A',
    });
  },
};
