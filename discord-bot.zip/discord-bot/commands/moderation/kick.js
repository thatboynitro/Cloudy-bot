const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { sendModLog } = require('../../utils/modlog');
const { isStaff } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick a member from the server')
    .addUserOption((opt) => opt.setName('user').setDescription('Who to kick').setRequired(true))
    .addStringOption((opt) => opt.setName('reason').setDescription('Reason for the kick'))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),
  async execute(interaction) {
    if (!isStaff(interaction, PermissionFlagsBits.KickMembers)) {
      return interaction.reply({ content: 'You don\'t have permission to kick members.', ephemeral: true });
    }

    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (!member) {
      return interaction.reply({ content: 'That user isn\'t in this server.', ephemeral: true });
    }
    if (!member.kickable) {
      return interaction.reply({ content: 'I can\'t kick that user — check role hierarchy and my permissions.', ephemeral: true });
    }

    const dmEmbed = new EmbedBuilder()
      .setColor(0xffa502)
      .setTitle(`👢 You were kicked from ${interaction.guild.name}`)
      .setThumbnail(interaction.guild.iconURL())
      .addFields({ name: 'Reason', value: reason })
      .setFooter({ text: 'You are welcome to rejoin if you have an invite link.' })
      .setTimestamp();

    await target.send({ embeds: [dmEmbed] }).catch(() => {});

    await member.kick(reason);

    const embed = new EmbedBuilder()
      .setColor(0xffa502)
      .setTitle('👢 Member Kicked')
      .addFields(
        { name: 'User', value: `${target.tag}`, inline: true },
        { name: 'Moderator', value: `${interaction.user.tag}`, inline: true },
        { name: 'Reason', value: reason },
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });

    await sendModLog(interaction.client, {
      action: '👢 Member Kicked',
      color: 0xffa502,
      target,
      moderator: interaction.user,
      reason,
    });
  },
};
