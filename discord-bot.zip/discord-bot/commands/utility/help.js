const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder().setName('help').setDescription('List all available commands'),
  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x5352ed)
      .setTitle('📖 Command List')
      .addFields(
        { name: '🎉 Fun', value: '`/marry` `/slap` `/kiss` `/fight` `/hug` `/pat` `/punch` `/holdhands` `/bonk` `/dance` `/highfive` `/tickle` `/yeet` `/8ball`' },
        { name: '🎮 Games', value: '`/rps` `/trivia` `/blackjack` `/coinflip` `/roll` `/slots` `/wheel` `/higherlower` `/tictactoe` `/hangman`' },
        { name: '💰 Economy', value: '`/balance` `/work` `/daily` `/fish` `/crime` `/gamble` `/steal` `/gift` `/leaderboard`' },
        {
          name: '🛡️ Moderation (staff only)',
          value: '`/ban` `/kick` `/mute` `/unmute` `/warn`',
        },
        { name: '🔧 Utility', value: '`/ping` `/help`' },
      )
      .setFooter({ text: 'More commands can be added anytime — just ask!' });

    await interaction.reply({ embeds: [embed] });
  },
};
