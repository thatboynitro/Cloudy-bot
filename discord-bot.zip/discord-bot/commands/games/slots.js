const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getBalance, addBalance } = require('../../utils/economy');

// Rarer symbols pay more. Weight = how common it is out of the total.
const SYMBOLS = [
  { emoji: '🍒', weight: 30, payout: 2 },
  { emoji: '🍋', weight: 25, payout: 3 },
  { emoji: '🔔', weight: 20, payout: 5 },
  { emoji: '⭐', weight: 15, payout: 10 },
  { emoji: '💎', weight: 8, payout: 25 },
  { emoji: '7️⃣', weight: 2, payout: 50 },
];

const TOTAL_WEIGHT = SYMBOLS.reduce((sum, s) => sum + s.weight, 0);

function spinReel() {
  const roll = Math.random() * TOTAL_WEIGHT;
  let cumulative = 0;
  for (const symbol of SYMBOLS) {
    cumulative += symbol.weight;
    if (roll <= cumulative) return symbol;
  }
  return SYMBOLS[0];
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('slots')
    .setDescription('Bet coins and spin the slot machine')
    .addIntegerOption((opt) =>
      opt.setName('bet').setDescription('How many coins to bet').setRequired(true).setMinValue(1),
    ),
  async execute(interaction) {
    const bet = interaction.options.getInteger('bet');
    const balance = getBalance(interaction.user.id);

    if (bet > balance) {
      return interaction.reply({ content: `You only have **${balance}** coins.`, ephemeral: true });
    }

    const reels = [spinReel(), spinReel(), spinReel()];
    const display = reels.map((r) => r.emoji).join(' | ');

    let winnings = 0;
    let resultText;

    if (reels[0].emoji === reels[1].emoji && reels[1].emoji === reels[2].emoji) {
      winnings = bet * reels[0].payout;
      resultText = `🎉 JACKPOT! Three ${reels[0].emoji} in a row! You won **${winnings}** coins!`;
    } else if (reels[0].emoji === reels[1].emoji || reels[1].emoji === reels[2].emoji || reels[0].emoji === reels[2].emoji) {
      winnings = Math.floor(bet * 1.2);
      resultText = `✨ Two matching symbols! You won **${winnings}** coins.`;
    } else {
      winnings = -bet;
      resultText = `💸 No match. You lost **${bet}** coins.`;
    }

    const newBalance = addBalance(interaction.user.id, winnings);

    const embed = new EmbedBuilder()
      .setColor(winnings > 0 ? 0x2ed573 : 0xff4757)
      .setTitle('🎰 Slots')
      .setDescription(`**[ ${display} ]**\n\n${resultText}\nNew balance: **${newBalance}** coins.`);

    await interaction.reply({ embeds: [embed] });
  },
};
