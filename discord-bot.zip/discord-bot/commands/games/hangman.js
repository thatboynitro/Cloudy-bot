const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { addBalance } = require('../../utils/economy');

const WORDS = [
  'DISCORD', 'JAVASCRIPT', 'PYTHON', 'KEYBOARD', 'ELEPHANT', 'GALAXY',
  'PIRATE', 'DRAGON', 'WIZARD', 'CASTLE', 'VOLCANO', 'PENGUIN',
  'SANDWICH', 'MYSTERY', 'ROBOT', 'JUNGLE', 'THUNDER', 'PUZZLE',
];

const MAX_WRONG = 6;
const REWARD = 50;

const STAGES = [
  '```\n \n \n \n \n \n```',
  '```\n  +---+\n  |   |\n      |\n      |\n      |\n=======```',
  '```\n  +---+\n  |   |\n  O   |\n      |\n      |\n=======```',
  '```\n  +---+\n  |   |\n  O   |\n  |   |\n      |\n=======```',
  '```\n  +---+\n  |   |\n  O   |\n /|   |\n      |\n=======```',
  '```\n  +---+\n  |   |\n  O   |\n /|\\  |\n      |\n=======```',
  '```\n  +---+\n  |   |\n  O   |\n /|\\  |\n / \\  |\n=======```',
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('hangman')
    .setDescription('Start a group hangman game in this channel — anyone can guess letters'),
  async execute(interaction) {
    const word = WORDS[Math.floor(Math.random() * WORDS.length)];
    const guessed = new Set();
    let wrongCount = 0;

    const displayWord = () =>
      word.split('').map((letter) => (guessed.has(letter) ? letter : '\\_')).join(' ');

    const buildEmbed = (statusText) =>
      new EmbedBuilder()
        .setColor(0x5352ed)
        .setTitle('🔤 Hangman')
        .setDescription(
          `${STAGES[wrongCount]}\n**Word:** ${displayWord()}\n**Guessed:** ${[...guessed].join(', ') || 'none yet'}\n**Wrong guesses:** ${wrongCount}/${MAX_WRONG}\n\n${statusText || 'Type a single letter in this channel to guess!'}`,
        );

    const msg = await interaction.reply({ embeds: [buildEmbed(null)], fetchReply: true });

    const collector = interaction.channel.createMessageCollector({
      filter: (m) => !m.author.bot && /^[a-zA-Z]$/.test(m.content.trim()),
      time: 5 * 60 * 1000,
    });

    collector.on('collect', async (message) => {
      const letter = message.content.trim().toUpperCase();
      message.delete().catch(() => {});

      if (guessed.has(letter)) return;
      guessed.add(letter);

      if (!word.includes(letter)) {
        wrongCount++;
      }

      if (wrongCount >= MAX_WRONG) {
        await msg.edit({ embeds: [buildEmbed(`💀 You lost! The word was **${word}**.`)] }).catch(() => {});
        collector.stop();
        return;
      }

      if (word.split('').every((l) => guessed.has(l))) {
        const newBalance = addBalance(message.author.id, REWARD);
        await msg
          .edit({
            embeds: [buildEmbed(`🎉 Solved by ${message.author}! The word was **${word}**.\n💰 +${REWARD} coins for them (new balance: ${newBalance}).`)],
          })
          .catch(() => {});
        collector.stop();
        return;
      }

      await msg.edit({ embeds: [buildEmbed(null)] }).catch(() => {});
    });

    collector.on('end', async (collected, reason) => {
      if (reason === 'time') {
        await msg.edit({ embeds: [buildEmbed(`⏱️ Time's up! The word was **${word}**.`)] }).catch(() => {});
      }
    });
  },
};
