const {
  SlashCommandBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
} = require('discord.js');
const { getBalance, addBalance } = require('../../utils/economy');

const SUITS = ['♠️', '♥️', '♦️', '♣️'];
const RANKS = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];

function newDeck() {
  const deck = [];
  for (const suit of SUITS) {
    for (const rank of RANKS) {
      deck.push({ rank, suit });
    }
  }
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
}

function cardValue(card) {
  if (card.rank === 'A') return 11;
  if (['J', 'Q', 'K'].includes(card.rank)) return 10;
  return parseInt(card.rank, 10);
}

function handTotal(hand) {
  let total = hand.reduce((sum, c) => sum + cardValue(c), 0);
  let aces = hand.filter((c) => c.rank === 'A').length;
  while (total > 21 && aces > 0) {
    total -= 10;
    aces--;
  }
  return total;
}

function formatHand(hand) {
  return hand.map((c) => `${c.rank}${c.suit}`).join(' ');
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('blackjack')
    .setDescription('Play blackjack against the dealer, optionally betting coins')
    .addIntegerOption((opt) =>
      opt.setName('bet').setDescription('Coins to bet (optional — leave blank to play for fun)').setMinValue(1),
    ),
  async execute(interaction) {
    const bet = interaction.options.getInteger('bet');

    if (bet) {
      const balance = getBalance(interaction.user.id);
      if (bet > balance) {
        return interaction.reply({ content: `You only have **${balance}** coins.`, ephemeral: true });
      }
    }

    const deck = newDeck();
    const player = [deck.pop(), deck.pop()];
    const dealer = [deck.pop(), deck.pop()];

    const betLine = bet ? `\n💰 Betting **${bet}** coins.` : '';

    const buildEmbed = (statusText, revealDealer = false) => {
      const dealerDisplay = revealDealer
        ? `${formatHand(dealer)} (${handTotal(dealer)})`
        : `${dealer[0].rank}${dealer[0].suit} 🂠`;

      return new EmbedBuilder()
        .setColor(0x2ed573)
        .setTitle('🃏 Blackjack')
        .addFields(
          { name: `Your hand (${handTotal(player)})`, value: formatHand(player) },
          { name: 'Dealer', value: dealerDisplay },
        )
        .setDescription(`${statusText || ''}${betLine}`.trim() || null);
    };

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('hit').setLabel('🃏 Hit').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('stand').setLabel('✋ Stand').setStyle(ButtonStyle.Secondary),
    );

    function settleBet(outcome) {
      // outcome: 'win' | 'lose' | 'push'
      if (!bet) return '';
      if (outcome === 'win') {
        const newBalance = addBalance(interaction.user.id, bet);
        return `\n🎉 You won **${bet}** coins! New balance: **${newBalance}**.`;
      }
      if (outcome === 'lose') {
        const newBalance = addBalance(interaction.user.id, -bet);
        return `\n💸 You lost **${bet}** coins. New balance: **${newBalance}**.`;
      }
      return `\n🤝 Bet returned. Balance unchanged.`;
    }

    const playerTotal = handTotal(player);
    if (playerTotal === 21) {
      const settlement = settleBet('win');
      return interaction.reply({ embeds: [buildEmbed(`🎉 Blackjack! You win!${settlement}`, true)] });
    }

    const msg = await interaction.reply({
      embeds: [buildEmbed(null)],
      components: [row],
      fetchReply: true,
    });

    const collector = msg.createMessageComponentCollector({
      filter: (i) => i.user.id === interaction.user.id,
      time: 60000,
    });

    collector.on('collect', async (btn) => {
      if (btn.customId === 'hit') {
        player.push(deck.pop());
        const total = handTotal(player);

        if (total > 21) {
          const settlement = settleBet('lose');
          await btn.update({ embeds: [buildEmbed(`💥 Bust! You went over 21. Dealer wins.${settlement}`, true)], components: [] });
          collector.stop();
          return;
        }
        if (total === 21) {
          await btn.update({ embeds: [buildEmbed('🎉 21! Great hand — standing automatically.')], components: [] });
          collector.stop('auto-stand');
          await resolveDealer(btn, true);
          return;
        }

        await btn.update({ embeds: [buildEmbed(null)], components: [row] });
      } else {
        collector.stop('stand');
        await resolveDealer(btn, false);
      }
    });

    async function resolveDealer(btn, wasEdit) {
      while (handTotal(dealer) < 17) {
        dealer.push(deck.pop());
      }

      const pTotal = handTotal(player);
      const dTotal = handTotal(dealer);

      let result;
      let settlement;
      if (dTotal > 21) {
        result = '🎉 Dealer busts! You win!';
        settlement = settleBet('win');
      } else if (dTotal > pTotal) {
        result = '💀 Dealer wins.';
        settlement = settleBet('lose');
      } else if (dTotal < pTotal) {
        result = '🎉 You win!';
        settlement = settleBet('win');
      } else {
        result = "🤝 It's a tie!";
        settlement = settleBet('push');
      }

      const finalEmbed = buildEmbed(`${result}${settlement}`, true);
      if (wasEdit) {
        await interaction.editReply({ embeds: [finalEmbed], components: [] });
      } else {
        await btn.update({ embeds: [finalEmbed], components: [] });
      }
    }

    collector.on('end', async (collected, reason) => {
      if (reason === 'time') {
        await interaction.editReply({ components: [] }).catch(() => {});
      }
    });
  },
};
