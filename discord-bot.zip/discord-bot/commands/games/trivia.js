const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const { addBalance } = require('../../utils/economy');

const REWARD = 20;

const QUESTIONS = [
  { q: 'What planet is known as the Red Planet?', choices: ['Venus', 'Mars', 'Jupiter', 'Saturn'], answer: 1 },
  { q: 'How many continents are there on Earth?', choices: ['5', '6', '7', '8'], answer: 2 },
  { q: 'What is the largest ocean on Earth?', choices: ['Atlantic', 'Indian', 'Arctic', 'Pacific'], answer: 3 },
  { q: 'Who wrote "Romeo and Juliet"?', choices: ['Dickens', 'Shakespeare', 'Austen', 'Tolstoy'], answer: 1 },
  { q: 'What is the chemical symbol for gold?', choices: ['Go', 'Gd', 'Au', 'Ag'], answer: 2 },
  { q: 'How many strings does a standard guitar have?', choices: ['4', '5', '6', '7'], answer: 2 },
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('trivia')
    .setDescription('Answer a random trivia question'),
  async execute(interaction) {
    const question = QUESTIONS[Math.floor(Math.random() * QUESTIONS.length)];

    const row = new ActionRowBuilder().addComponents(
      question.choices.map((choice, i) =>
        new ButtonBuilder().setCustomId(`${i}`).setLabel(choice).setStyle(ButtonStyle.Secondary),
      ),
    );

    const questionEmbed = new EmbedBuilder()
      .setColor(0x5352ed)
      .setTitle('🧠 Trivia Time')
      .setDescription(question.q)
      .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL() })
      .setFooter({ text: 'You have 20 seconds to answer!' });

    const msg = await interaction.reply({
      embeds: [questionEmbed],
      components: [row],
      fetchReply: true,
    });

    try {
      const btn = await msg.awaitMessageComponent({
        filter: (i) => i.user.id === interaction.user.id,
        time: 20000,
      });

      const correct = parseInt(btn.customId, 10) === question.answer;
      if (correct) addBalance(interaction.user.id, REWARD);

      const resultEmbed = new EmbedBuilder()
        .setColor(correct ? 0x2ed573 : 0xff4757)
        .setTitle('🧠 Trivia Time')
        .setDescription(question.q)
        .addFields({
          name: 'Result',
          value: correct
            ? `✅ Correct! **+${REWARD}** coins.`
            : `❌ Not quite. The correct answer was **${question.choices[question.answer]}**.`,
        });

      await btn.update({ embeds: [resultEmbed], components: [] });
    } catch {
      const timeoutEmbed = new EmbedBuilder()
        .setColor(0x747d8c)
        .setTitle('🧠 Trivia Time')
        .setDescription(question.q)
        .addFields({
          name: 'Result',
          value: `⏱️ Time's up! The answer was **${question.choices[question.answer]}**.`,
        });

      await interaction.editReply({ embeds: [timeoutEmbed], components: [] });
    }
  },
};
