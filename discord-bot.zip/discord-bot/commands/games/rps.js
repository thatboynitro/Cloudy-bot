const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const { addBalance } = require('../../utils/economy');

const REWARD = 15;

const CHOICES = ['rock', 'paper', 'scissors'];
const EMOJI = { rock: '🪨', paper: '📄', scissors: '✂️' };

function decideWinner(a, b) {
  if (a === b) return 'tie';
  if ((a === 'rock' && b === 'scissors') || (a === 'paper' && b === 'rock') || (a === 'scissors' && b === 'paper')) {
    return 'a';
  }
  return 'b';
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rps')
    .setDescription('Play rock-paper-scissors against the bot'),
  async execute(interaction) {
    const row = new ActionRowBuilder().addComponents(
      CHOICES.map((c) =>
        new ButtonBuilder().setCustomId(c).setLabel(`${EMOJI[c]} ${c}`).setStyle(ButtonStyle.Primary),
      ),
    );

    const introEmbed = new EmbedBuilder()
      .setColor(0x5352ed)
      .setTitle('🪨📄✂️ Rock, Paper, Scissors')
      .setDescription('Pick your move below — you have 30 seconds!')
      .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL() });

    const msg = await interaction.reply({
      embeds: [introEmbed],
      components: [row],
      fetchReply: true,
    });

    try {
      const btn = await msg.awaitMessageComponent({
        filter: (i) => i.user.id === interaction.user.id,
        time: 30000,
      });

      const userChoice = btn.customId;
      const botChoice = CHOICES[Math.floor(Math.random() * CHOICES.length)];
      const result = decideWinner(userChoice, botChoice);

      const resultText =
        result === 'tie'
          ? "🤝 It's a tie!"
          : result === 'a'
            ? `🎉 You win! **+${REWARD}** coins.`
            : '🤖 The bot wins!';

      if (result === 'a') addBalance(interaction.user.id, REWARD);

      const embed = new EmbedBuilder()
        .setColor(result === 'a' ? 0x2ed573 : result === 'b' ? 0xff4757 : 0xffa502)
        .setTitle('🪨📄✂️ Rock, Paper, Scissors — Result')
        .addFields(
          { name: 'You chose', value: `${EMOJI[userChoice]} ${userChoice}`, inline: true },
          { name: 'Bot chose', value: `${EMOJI[botChoice]} ${botChoice}`, inline: true },
        )
        .setDescription(resultText)
        .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL() });

      await btn.update({ embeds: [embed], components: [] });
    } catch {
      const timeoutEmbed = new EmbedBuilder()
        .setColor(0x747d8c)
        .setDescription('⏱️ You didn\'t choose in time!');
      await interaction.editReply({ embeds: [timeoutEmbed], components: [] });
    }
  },
};
