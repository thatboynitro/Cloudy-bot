const {
  SlashCommandBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
} = require('discord.js');
const { getBalance, addBalance } = require('../../utils/economy');

const MULTIPLIER_STEP = 1.4;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('higherlower')
    .setDescription('Guess if the next number is higher or lower — cash out before you\'re wrong!')
    .addIntegerOption((opt) =>
      opt.setName('bet').setDescription('How many coins to bet').setRequired(true).setMinValue(1),
    ),
  async execute(interaction) {
    const bet = interaction.options.getInteger('bet');
    const balance = getBalance(interaction.user.id);

    if (bet > balance) {
      return interaction.reply({ content: `You only have **${balance}** coins.`, ephemeral: true });
    }

    let current = Math.floor(Math.random() * 100) + 1;
    let multiplier = 1;
    let round = 0;

    const buildRow = (canCashOut) =>
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('higher').setLabel('⬆️ Higher').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId('lower').setLabel('⬇️ Lower').setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('cashout')
          .setLabel('💰 Cash Out')
          .setStyle(ButtonStyle.Primary)
          .setDisabled(!canCashOut),
      );

    const buildEmbed = (statusText) =>
      new EmbedBuilder()
        .setColor(0x5352ed)
        .setTitle('🔢 Higher or Lower')
        .setDescription(
          `Current number: **${current}**\n` +
          `Current multiplier: **${multiplier.toFixed(2)}x** (${round} correct)\n` +
          `Potential payout: **${Math.floor(bet * multiplier)}** coins\n\n${statusText || 'Will the next number be higher or lower?'}`,
        );

    const msg = await interaction.reply({
      embeds: [buildEmbed(null)],
      components: [buildRow(false)],
      fetchReply: true,
    });

    const collector = msg.createMessageComponentCollector({
      filter: (i) => i.user.id === interaction.user.id,
      time: 60000,
    });

    collector.on('collect', async (btn) => {
      if (btn.customId === 'cashout') {
        const payout = Math.floor(bet * multiplier);
        const newBalance = addBalance(interaction.user.id, payout - bet);
        await btn.update({
          embeds: [buildEmbed(`💰 Cashed out! You won **${payout - bet}** coins.\nNew balance: **${newBalance}** coins.`)],
          components: [],
        });
        collector.stop();
        return;
      }

      const next = Math.floor(Math.random() * 100) + 1;
      const guessHigher = btn.customId === 'higher';
      const correct = next === current ? false : guessHigher ? next > current : next < current;

      if (!correct) {
        const newBalance = addBalance(interaction.user.id, -bet);
        await btn.update({
          embeds: [buildEmbed(`❌ Wrong! The number was **${next}**. You lost **${bet}** coins.\nNew balance: **${newBalance}** coins.`)],
          components: [],
        });
        collector.stop();
        return;
      }

      current = next;
      multiplier *= MULTIPLIER_STEP;
      round++;

      await btn.update({ embeds: [buildEmbed('✅ Correct! Keep going or cash out.')], components: [buildRow(true)] });
    });

    collector.on('end', async (collected, reason) => {
      if (reason === 'time') {
        await interaction.editReply({ components: [] }).catch(() => {});
      }
    });
  },
};
