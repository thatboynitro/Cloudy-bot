const {
  SlashCommandBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
} = require('discord.js');

const WIN_LINES = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
  [0, 3, 6], [1, 4, 7], [2, 5, 8], // columns
  [0, 4, 8], [2, 4, 6],           // diagonals
];

function checkWinner(board) {
  for (const [a, b, c] of WIN_LINES) {
    if (board[a] && board[a] === board[b] && board[b] === board[c]) return board[a];
  }
  if (board.every((cell) => cell)) return 'draw';
  return null;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('tictactoe')
    .setDescription('Challenge another member to tic-tac-toe')
    .addUserOption((opt) => opt.setName('user').setDescription('Who to challenge').setRequired(true)),
  async execute(interaction) {
    const playerX = interaction.user;
    const playerO = interaction.options.getUser('user');

    if (playerO.bot) {
      return interaction.reply({ content: 'You can\'t challenge a bot.', ephemeral: true });
    }
    if (playerO.id === playerX.id) {
      return interaction.reply({ content: 'You can\'t play against yourself!', ephemeral: true });
    }

    const board = Array(9).fill(null);
    let turn = playerX.id;

    const buildRows = () => {
      const rows = [];
      for (let r = 0; r < 3; r++) {
        const row = new ActionRowBuilder();
        for (let c = 0; c < 3; c++) {
          const idx = r * 3 + c;
          const cell = board[idx];
          row.addComponents(
            new ButtonBuilder()
              .setCustomId(`cell_${idx}`)
              .setLabel(cell || '\u200b')
              .setStyle(cell === 'X' ? ButtonStyle.Danger : cell === 'O' ? ButtonStyle.Primary : ButtonStyle.Secondary)
              .setDisabled(!!cell),
          );
        }
        rows.push(row);
      }
      return rows;
    };

    const buildEmbed = (statusText) =>
      new EmbedBuilder()
        .setColor(0x5352ed)
        .setTitle('⭕ Tic-Tac-Toe')
        .setDescription(`${playerX} (❌) vs ${playerO} (⭕)\n\n${statusText}`);

    const msg = await interaction.reply({
      embeds: [buildEmbed(`It's <@${turn}>'s turn (❌)`)],
      components: buildRows(),
      fetchReply: true,
    });

    const collector = msg.createMessageComponentCollector({ time: 5 * 60 * 1000 });

    collector.on('collect', async (btn) => {
      if (btn.user.id !== turn) {
        return btn.reply({ content: 'It\'s not your turn!', ephemeral: true });
      }

      const idx = parseInt(btn.customId.split('_')[1], 10);
      if (board[idx]) {
        return btn.reply({ content: 'That spot is taken!', ephemeral: true });
      }

      const symbol = turn === playerX.id ? 'X' : 'O';
      board[idx] = symbol;

      const winner = checkWinner(board);
      if (winner === 'draw') {
        await btn.update({ embeds: [buildEmbed('🤝 It\'s a draw!')], components: buildRows() });
        collector.stop();
        return;
      }
      if (winner) {
        const winnerUser = winner === 'X' ? playerX : playerO;
        await btn.update({ embeds: [buildEmbed(`🎉 ${winnerUser} wins!`)], components: buildRows() });
        collector.stop();
        return;
      }

      turn = turn === playerX.id ? playerO.id : playerX.id;
      const nextSymbol = turn === playerX.id ? '❌' : '⭕';
      await btn.update({ embeds: [buildEmbed(`It's <@${turn}>'s turn (${nextSymbol})`)], components: buildRows() });
    });

    collector.on('end', async (collected, reason) => {
      if (reason === 'time') {
        await interaction.editReply({ components: [] }).catch(() => {});
      }
    });
  },
};
