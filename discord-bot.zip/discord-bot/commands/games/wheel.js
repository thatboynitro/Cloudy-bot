const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getBalance, addBalance } = require('../../utils/economy');

// Rarer/bigger multipliers are less likely.
const SEGMENTS = [
  { label: '💥 Bust', multiplier: 0, weight: 20 },
  { label: '0.5x', multiplier: 0.5, weight: 25 },
  { label: '1x (push)', multiplier: 1, weight: 20 },
  { label: '1.5x', multiplier: 1.5, weight: 18 },
  { label: '2x', multiplier: 2, weight: 12 },
  { label: '3x', multiplier: 3, weight: 4 },
  { label: '🌟 5x', multiplier: 5, weight: 1 },
];

const TOTAL_WEIGHT = SEGMENTS.reduce((sum, s) => sum + s.weight, 0);

function spin() {
  const roll = Math.random() * TOTAL_WEIGHT;
  let cumulative = 0;
  for (const segment of SEGMENTS) {
    cumulative += segment.weight;
    if (roll <= cumulative) return segment;
  }
  return SEGMENTS[0];
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('wheel')
    .setDescription('Bet coins and spin the wheel for a random multiplier')
    .addIntegerOption((opt) =>
      opt.setName('bet').setDescription('How many coins to bet').setRequired(true).setMinValue(1),
    ),
  async execute(interaction) {
    const bet = interaction.options.getInteger('bet');
    const balance = getBalance(interaction.user.id);

    if (bet > balance) {
      return interaction.reply({ content: `You only have **${balance}** coins.`, ephemeral: true });
    }

    const result = spin();
    const payout = Math.floor(bet * result.multiplier);
    const change = payout - bet;
    const newBalance = addBalance(interaction.user.id, change);

    const embed = new EmbedBuilder()
      .setColor(change > 0 ? 0x2ed573 : change === 0 ? 0xffa502 : 0xff4757)
      .setTitle('🎡 Wheel Spin')
      .setDescription(
        `The wheel landed on **${result.label}**!\n\n` +
        (change > 0
          ? `🎉 You won **${change}** coins!`
          : change === 0
            ? "🤝 You broke even."
            : `💸 You lost **${Math.abs(change)}** coins.`) +
        `\nNew balance: **${newBalance}** coins.`,
      );

    await interaction.reply({ embeds: [embed] });
  },
};
