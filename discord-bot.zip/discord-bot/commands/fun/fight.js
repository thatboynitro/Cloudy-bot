const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getRandomGif } = require('../../utils/gif');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('fight')
    .setDescription('Playfully fight another member')
    .addUserOption((opt) =>
      opt.setName('user').setDescription('Who are you fighting?').setRequired(true),
    ),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const author = interaction.user;

    if (target.bot) {
      return interaction.reply({ content: 'You can\'t fight a bot. 🤖', ephemeral: true });
    }
    if (target.id === author.id) {
      return interaction.reply(`${author} fights themselves. That's rough. 😵`);
    }

    const gif = await getRandomGif('anime fight');
    const embed = new EmbedBuilder()
      .setColor(0xe74c3c)
      .setDescription(`⚔️ ${author} is fighting ${target}!`);
    if (gif) embed.setImage(gif);

    await interaction.reply({ embeds: [embed] });
  },
};
