const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getRandomGif } = require('../../utils/gif');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('pat')
    .setDescription('Give another member a headpat')
    .addUserOption((opt) => opt.setName('user').setDescription('Who are you patting?').setRequired(true)),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const author = interaction.user;

    const gif = await getRandomGif('anime headpat');
    const embed = new EmbedBuilder()
      .setColor(0x70a1ff)
      .setDescription(`✋ ${author} gave ${target} a headpat!`);
    if (gif) embed.setImage(gif);

    await interaction.reply({ embeds: [embed] });
  },
};
