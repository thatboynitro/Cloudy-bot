const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getRandomGif } = require('../../utils/gif');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('yeet')
    .setDescription('Yeet another member into the sun')
    .addUserOption((opt) => opt.setName('user').setDescription('Who are you yeeting?').setRequired(true)),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const author = interaction.user;

    if (target.id === author.id) {
      return interaction.reply(`${author} yeets themselves. Bold strategy. 🚀`);
    }

    const gif = await getRandomGif('anime throw yeet');
    const embed = new EmbedBuilder()
      .setColor(0xe67e22)
      .setDescription(`🚀 ${author} yeeted ${target} into the sun!`);
    if (gif) embed.setImage(gif);

    await interaction.reply({ embeds: [embed] });
  },
};
