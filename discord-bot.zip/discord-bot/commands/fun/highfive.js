const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getRandomGif } = require('../../utils/gif');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('highfive')
    .setDescription('Give another member a high five')
    .addUserOption((opt) => opt.setName('user').setDescription('Who are you high-fiving?').setRequired(true)),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const author = interaction.user;

    if (target.id === author.id) {
      return interaction.reply(`${author} tries to high five themselves and misses. 😅`);
    }

    const gif = await getRandomGif('anime high five');
    const embed = new EmbedBuilder()
      .setColor(0xffd700)
      .setDescription(`🙌 ${author} high-fived ${target}!`);
    if (gif) embed.setImage(gif);

    await interaction.reply({ embeds: [embed] });
  },
};
