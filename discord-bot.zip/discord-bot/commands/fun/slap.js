const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getRandomGif } = require('../../utils/gif');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('slap')
    .setDescription('Slap another member (playfully!)')
    .addUserOption((opt) =>
      opt.setName('user').setDescription('Who are you slapping?').setRequired(true),
    ),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const author = interaction.user;

    if (target.id === author.id) {
      return interaction.reply(`${author} slaps themselves. That's... a choice. 😬`);
    }

    const gif = await getRandomGif('anime slap');
    const embed = new EmbedBuilder()
      .setColor(0xff4757)
      .setDescription(`👋 ${author} slapped ${target}!`);
    if (gif) embed.setImage(gif);

    await interaction.reply({ embeds: [embed] });
  },
};
