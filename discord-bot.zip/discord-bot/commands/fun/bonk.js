const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getRandomGif } = require('../../utils/gif');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('bonk')
    .setDescription('Bonk another member (go to horny jail)')
    .addUserOption((opt) => opt.setName('user').setDescription('Who are you bonking?').setRequired(true)),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const author = interaction.user;

    if (target.id === author.id) {
      return interaction.reply(`${author} bonks themselves. Self-discipline! 🔨`);
    }

    const gif = await getRandomGif('anime bonk');
    const embed = new EmbedBuilder()
      .setColor(0xffa502)
      .setDescription(`🔨 ${author} bonked ${target}! Go to horny jail.`);
    if (gif) embed.setImage(gif);

    await interaction.reply({ embeds: [embed] });
  },
};
