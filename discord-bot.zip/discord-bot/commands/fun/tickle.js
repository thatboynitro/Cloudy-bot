const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getRandomGif } = require('../../utils/gif');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('tickle')
    .setDescription('Tickle another member')
    .addUserOption((opt) => opt.setName('user').setDescription('Who are you tickling?').setRequired(true)),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const author = interaction.user;

    if (target.id === author.id) {
      return interaction.reply(`${author} tries to tickle themselves. Turns out it doesn't work. 😂`);
    }

    const gif = await getRandomGif('anime tickle');
    const embed = new EmbedBuilder()
      .setColor(0xff9ff3)
      .setDescription(`🤣 ${author} is tickling ${target}!`);
    if (gif) embed.setImage(gif);

    await interaction.reply({ embeds: [embed] });
  },
};
