const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getRandomGif } = require('../../utils/gif');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kiss')
    .setDescription('Give another member a kiss (wholesome!)')
    .addUserOption((opt) =>
      opt.setName('user').setDescription('Who are you kissing?').setRequired(true),
    ),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const author = interaction.user;

    if (target.id === author.id) {
      return interaction.reply(`${author} blows a kiss to the mirror. 💋`);
    }

    const gif = await getRandomGif('anime kiss');
    const embed = new EmbedBuilder()
      .setColor(0xff85c0)
      .setDescription(`💋 ${author} kissed ${target}!`);
    if (gif) embed.setImage(gif);

    await interaction.reply({ embeds: [embed] });
  },
};
