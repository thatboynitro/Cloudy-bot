const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getRandomGif } = require('../../utils/gif');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('marry')
    .setDescription('Propose marriage to another member (just for fun!)')
    .addUserOption((opt) =>
      opt.setName('user').setDescription('Who do you want to marry?').setRequired(true),
    ),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const author = interaction.user;

    if (target.id === author.id) {
      return interaction.reply({ content: 'You can\'t marry yourself... or can you? 🤔', ephemeral: true });
    }
    if (target.bot) {
      return interaction.reply({ content: 'Bots can\'t consent to marriage. 😅' });
    }

    const gif = await getRandomGif('anime proposal wedding');
    const embed = new EmbedBuilder()
      .setColor(0xff69b4)
      .setDescription(`💍 ${author} got down on one knee and proposed to ${target}!\n\n${target}, do you accept?`)
      .setFooter({ text: 'This is just for fun — no data is saved.' });
    if (gif) embed.setImage(gif);

    await interaction.reply({ content: `${target}`, embeds: [embed] });
  },
};
