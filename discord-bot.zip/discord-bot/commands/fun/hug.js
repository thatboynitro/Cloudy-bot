const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getRandomGif } = require('../../utils/gif');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('hug')
    .setDescription('Give another member a warm hug')
    .addUserOption((opt) => opt.setName('user').setDescription('Who are you hugging?').setRequired(true)),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const author = interaction.user;

    if (target.id === author.id) {
      return interaction.reply(`${author} hugs themselves. Self-love! 🤗`);
    }

    const gif = await getRandomGif('anime hug');
    const embed = new EmbedBuilder()
      .setColor(0xffa502)
      .setDescription(`🤗 ${author} hugged ${target}!`);
    if (gif) embed.setImage(gif);

    await interaction.reply({ embeds: [embed] });
  },
};
