const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getRandomGif } = require('../../utils/gif');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('punch')
    .setDescription('Playfully punch another member')
    .addUserOption((opt) => opt.setName('user').setDescription('Who are you punching?').setRequired(true)),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const author = interaction.user;

    if (target.id === author.id) {
      return interaction.reply(`${author} punches themselves. Ouch, why? 😵`);
    }

    const gif = await getRandomGif('anime punch');
    const embed = new EmbedBuilder()
      .setColor(0xe74c3c)
      .setDescription(`👊 ${author} punched ${target}!`);
    if (gif) embed.setImage(gif);

    await interaction.reply({ embeds: [embed] });
  },
};
