const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getRandomGif } = require('../../utils/gif');

module.exports = {
  data: new SlashCommandBuilder().setName('dance').setDescription('Bust out a dance move'),
  async execute(interaction) {
    const author = interaction.user;

    const gif = await getRandomGif('anime dance');
    const embed = new EmbedBuilder()
      .setColor(0x9b59b6)
      .setDescription(`💃 ${author} is dancing!`);
    if (gif) embed.setImage(gif);

    await interaction.reply({ embeds: [embed] });
  },
};
