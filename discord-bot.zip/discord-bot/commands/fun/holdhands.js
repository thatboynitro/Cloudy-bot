const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getRandomGif } = require('../../utils/gif');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('holdhands')
    .setDescription('Hold hands with another member')
    .addUserOption((opt) => opt.setName('user').setDescription('Who are you holding hands with?').setRequired(true)),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const author = interaction.user;

    if (target.id === author.id) {
      return interaction.reply(`${author} holds their own hand. Comforting. 🥹`);
    }

    const gif = await getRandomGif('anime holding hands');
    const embed = new EmbedBuilder()
      .setColor(0xff9ff3)
      .setDescription(`🤝 ${author} is holding hands with ${target}!`);
    if (gif) embed.setImage(gif);

    await interaction.reply({ embeds: [embed] });
  },
};
