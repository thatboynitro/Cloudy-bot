# My Discord Bot

A ready-to-run Discord bot with fun commands, mini-games, and moderation tools —
no coding experience needed to get it running.

## What it can do

- **Fun:** `/marry`, `/slap`, `/kiss`, `/fight` (interactive turn-based battle with buttons)
- **Games:** `/rps` (rock-paper-scissors vs the bot), `/trivia`
- **Moderation:** `/ban`, `/kick`, `/mute`, `/unmute`, `/warn`
- **Utility:** `/ping`, `/help`

## Step 1 — Create your bot on Discord

1. Go to https://discord.com/developers/applications and click **New Application**. Name it whatever you want.
2. In the left sidebar, click **Bot**. Click **Reset Token** (or **Add Bot**) and copy the token that appears — keep this secret, it's like a password.
3. On the same Bot page, scroll to **Privileged Gateway Intents** and turn ON:
   - Server Members Intent
   - Message Content Intent
4. In the left sidebar, click **OAuth2 → General** and copy the **Client ID** near the top.
5. Still under OAuth2, click **URL Generator**. Check the `bot` and `applications.commands` scopes. Under Bot Permissions, check: Administrator (easiest for now — you can lock this down later).
6. Copy the generated URL at the bottom, paste it into your browser, and invite the bot to your server.

## Step 2 — Get your server ID

In Discord, go to User Settings → Advanced → turn on **Developer Mode**. Then right-click your server icon and choose **Copy Server ID**.

## Step 3 — Fill in your secrets

1. Rename `.env.example` to `.env`.
2. Open it and fill in:
   - `DISCORD_TOKEN` — the bot token from Step 1
   - `CLIENT_ID` — the Client ID from Step 1
   - `GUILD_ID` — your server ID from Step 2

## Step 4 — Install and run

You'll need [Node.js](https://nodejs.org) installed (download the LTS version, click through the installer with defaults).

Open a terminal in this folder and run:

```
npm install
npm run deploy
npm start
```

- `npm install` downloads the required libraries.
- `npm run deploy` registers the slash commands to your server (do this once, and again anytime you add/change commands).
- `npm start` starts the bot. Leave this running — if you close the terminal, the bot goes offline.

If it worked, you'll see `✅ Logged in as YourBotName#1234` in the terminal, and the bot will show online in Discord.

## Step 5 — Keep it running 24/7 for free (using UptimeRobot)

Replit's free tier goes to sleep after a few minutes of no traffic. The bot code already includes a tiny built-in web server for this — you just need a free service to "ping" it every few minutes so it never falls asleep.

1. Start your bot in Replit (`npm start`) and find the **web preview URL** at the top of the preview pane (something like `https://discord-bot.yourname.repl.co`). Copy it.
2. Go to **uptimerobot.com** and create a free account.
3. Click **+ Add New Monitor**.
   - Monitor Type: **HTTP(s)**
   - Friendly Name: anything, like "Discord Bot"
   - URL: paste your Replit preview URL
   - Monitoring Interval: 5 minutes
4. Save it. UptimeRobot will now visit your bot every 5 minutes, which keeps Replit from putting it to sleep.

**Heads up:** this free workaround can occasionally stop working if Replit changes their sleep policy, and even with it your bot may have a few seconds of downtime around each wake-up. If you outgrow this or want guaranteed 24/7 uptime, Replit's paid "Reserved VM" deployment (a few dollars a month) removes sleep entirely with no extra setup — everything in this project works as-is either way.

## Adding more commands later

Every command is its own small file inside `commands/fun`, `commands/games`, `commands/moderation`, or `commands/utility`. To add a new one, copy an existing file in the right folder as a template, then run `npm run deploy` again. Just ask me for any specific command and I'll write the file for you.
